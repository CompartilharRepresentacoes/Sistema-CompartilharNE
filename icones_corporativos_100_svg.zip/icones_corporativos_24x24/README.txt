Ícones corporativos 24x24 | SVG | traço azul escuro #123E7A | fundo transparente | sem círculo/bola de fundo.
5 categorias x 20 ícones = 100 arquivos.
